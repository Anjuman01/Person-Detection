package com.example.updatefinalpir;

public class MainDevices {

    private String Description_device;
    private int Image_Thumbnail_device;

    public MainDevices(String description_device, int image_Thumbnail_device) {
        Description_device = description_device;
        Image_Thumbnail_device = image_Thumbnail_device;
    }

    public String getDescription_device() {
        return Description_device;
    }

    public void setDescription_device(String description_device) {
        Description_device = description_device;
    }

    public int getImage_Thumbnail_device() {
        return Image_Thumbnail_device;
    }

    public void setImage_Thumbnail_device(int image_Thumbnail_device) {
        Image_Thumbnail_device = image_Thumbnail_device;
    }

    public MainDevices() {
    }
}
