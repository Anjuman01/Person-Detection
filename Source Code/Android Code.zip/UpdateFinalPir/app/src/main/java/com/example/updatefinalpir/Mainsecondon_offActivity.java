package com.example.updatefinalpir;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Mainsecondon_offActivity extends AppCompatActivity {
    TextView equp_name,ImgDescription_device_Thing;
    List<MainDevices> maindevice;
    private TextView equipment,Room_name,S_Time,E_Time;;
    ImageView img_device_Thing;
    Button on_btn,off_btn;
    int po_bt;
    Context context;
    boolean isCheked = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainsecondon_off);

        //Receive data
        ImgDescription_device_Thing=findViewById(R.id.textView_new);

        //Receive data
        Intent intent = getIntent();
        String Description_Image = intent.getExtras().getString("Description");
        ImgDescription_device_Thing.setText(Description_Image);
        po_bt =intent.getExtras().getInt("position");

        maindevice = new ArrayList<>();
        maindevice.add(new MainDevices("Bulb",R.drawable.bulb));
        maindevice.add(new MainDevices("Fan",R.drawable.fan));


        RecyclerView Myrv = (RecyclerView)findViewById(R.id.my_recycler_view_new);
        DeviceViewHolder_new MyAdapter_Device_thing = new DeviceViewHolder_new(this,maindevice);
        Myrv.setLayoutManager(new GridLayoutManager(this,2));
        Myrv.setAdapter(MyAdapter_Device_thing);


    }

}
