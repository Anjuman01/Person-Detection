package com.example.updatefinalpir;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DeviceViewHolder_new extends RecyclerView.Adapter<DeviceViewHolder_new.MyDevice_ThingHolder> {
    private Context mContext;
    private List<MainDevices> mData_devices;

    public DeviceViewHolder_new(Context mContext, List<MainDevices> mData_device) {
        this.mContext = mContext;
        this.mData_devices = mData_device;
    }

    @NonNull
    @Override
    public MyDevice_ThingHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater mInlater = LayoutInflater.from(mContext);
        view=mInlater.inflate(R.layout.card_view_new,parent,false);
        return new MyDevice_ThingHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyDevice_ThingHolder holder, final int position) {

       // holder.Image_titles_device_Thing.setText(mData_devices.get(position).getImage_Thumbnail_device());
        holder.Image_book_thumbnail_device_Thing.setImageResource(mData_devices.get(position).getImage_Thumbnail_device());

    }

    @Override
    public int getItemCount() {
        return mData_devices.size();
    }

    public class MyDevice_ThingHolder extends RecyclerView.ViewHolder {
        TextView Image_titles_device_Thing;
        ImageView Image_book_thumbnail_device_Thing;
        CardView Image_card_device_Thing;

        public MyDevice_ThingHolder(View itemView) {
            super(itemView);
           // Image_titles_device_Thing=(TextView)itemView.findViewById(R.id.Image_Title_card_device_thing_new);
            Image_book_thumbnail_device_Thing=(ImageView)itemView.findViewById(R.id.card_image_device_thing_new);
            Image_card_device_Thing=(CardView) itemView.findViewById(R.id.card_View_new_new);
        }
    }
}

