package com.example.updatefinalpir;

import android.app.Activity;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DeviceActivity extends AppCompatActivity {
    List<MainDevices> maindevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device);

        maindevice = new ArrayList<>();
        maindevice.add(new MainDevices("Leavingroom",R.drawable.livingroom));
        maindevice.add(new MainDevices("Kitchen",R.drawable.kitchen));
        maindevice.add(new MainDevices("Kitchen",R.drawable.three));
        maindevice.add(new MainDevices("corridar",R.drawable.four));

        RecyclerView Myrv = (RecyclerView)findViewById(R.id.my_recycler_view);
        DeviceViewHolder MyAdapter_Device_thing = new DeviceViewHolder(this,maindevice);
        Myrv.setLayoutManager(new GridLayoutManager(this,2));
        Myrv.setAdapter(MyAdapter_Device_thing);




    }
}
